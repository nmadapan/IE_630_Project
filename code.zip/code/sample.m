close all;
clear;
clc;

a = [5, 4, 2, 6, 0]
[b, c] =  sort(a);
d = 1:numel(a);
b
c
b(c)
K = sortrows([c;d]',1);
e = K(:, 2);
b(e)

% rng(2)
% y = round(2 * rand(4, 1) - 1, 1);
% y(3) = 1;
% y
% yr = [-0.9, -0.5, 0, 0.5, 1];
% Ny = numel(yr);
% n_yr = repmat(yr, numel(y), 1);
% [s_n_yr, K] = sort([n_yr, y], 2);
% K == Ny+1
% [row, col] = find(K == Ny + 1);
% A = sortrows([row, col], 1)
% final_y_ids = A(:, 2)
% final_y_ids = final_y_ids - sum(y == yr, 2)