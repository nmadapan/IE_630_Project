close all;
clear;
clc;

%%
load('data_x.mat')
in_normal_flags = in_normal_flags(in_eps_flags);
in_oar_flags = in_oar_flags(in_eps_flags);
in_tumor_flags = in_tumor_flags(in_eps_flags);
indices = indices(in_eps_flags);
intensity_list = intensity_list(in_eps_flags);

% Create D matrix: No. of voxels x No. of coll. cells
N_voxels = numel(in_eps_flags);
N_coll = numel(yc_pts) * numel(zc_pts);
D = zeros(N_voxels, N_coll);
