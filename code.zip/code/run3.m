%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create the data for the IMRT Problem. 
% 
% Assumptions:
%   1. There is one tumor, three organs at risk and normal tissue. 
%   2. The region is sub-divided into cuboidal voxels. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear;
close all;
clc;

%% Initialization: Collimator
CY = 1; % CZ = CY % Half side of the the collimator. 
CN = 2*CY / 0.5; % No. of points on each axes (Y and Z) of collimator. 

%% Initialization: Ellipse
EX = 10; % Half x-axis of the Ellipse
EY = 5; % Half y-axis of the Ellipse
EZ = 2; % Half z-axis of the Ellipse
% dd = 0.4;
% dxe = dd; dye = dd; dze = dd;
% Nx = ceil(2*EX/dxe); if(rem(Nx, 2) == 0); Nx = Nx + 1; end
% Ny = ceil(2*EY/dye); if(rem(Ny, 2) == 0); Ny = Ny + 1; end
% Nz = ceil(2*EZ/dze); if(rem(Nz, 2) == 0); Nz = Nz + 1; end
N = 20;
Nx = N + 1;
Ny = N + 1;
Nz = N + 1;
dxe = 2*EX/Nx; % Range along x-axis is 20
dye = 2*EY/Ny; % Range along y-axis is 10
dze = 2*EZ/Nz; % Range along z-axis is 4
% TODO: Need to play with this threshold. 
% d_thresh = norm([dxe, dye, dze]);
% d_thresh = min([dxe, dye, dze]);
% d_thresh = sqrt(2)/2.81; % Based on the collimator resolution. 


%% Initialization: Properties
F = 1;
ALPH_T = 1e-2;
ALPH_N = 1e-2;
ALPH_O = 1e-2;
UNIT_DISTANCE = dxe;
COUNT = 0;

%% Initialization: Create symbols and ellipse equations
tic;
syms x y z E T O1 O2 O3;
E = x^2/(EX^2) + y^2/(EY^2) - 1; % Elliptical region which is the body. 
T = x^2 + y^2 + z^2 - 1; % Tumor
O1 = (x-3)^2 + 4*y^2 + z^2/4 - 1; % Organ at risk 
O2 = 4*(x-3)^2 + 4*(y-3)^2 + 4*z^2 - 1; % Organ at risk
O3 = 4*x^2 + 9*(y-2)^2 + 16*z^2 - 1; % Organ at risk
fprintf('Creating sybmbols: %.02f seconds\n', toc);

%% Plot tumor, critical organs, normal tissue
% Note that the plotting is done on x-axis. 
tic
figure;
hold on;
grid on;
ezplot(E, [-1*EX, EX, -1 * EY, EY])
ezplot(subs(T, z, 0), [-1*EX, EX, -1 * EY, EY])
ezplot(subs(O1, z, 0), [-1*EX, EX, -1 * EY, EY])
ezplot(subs(O2, z, 0), [-1*EX, EX, -1 * EY, EY])
ezplot(subs(O3, z, 0), [-1*EX, EX, -1 * EY, EY])
xlim([-1*(EX+0.5), EX+0.5])
ylim([-1*(EY+0.5), EY+0.5])
fprintf('Plotting: %.02f seconds\n', toc);

%% Create the BODY MESH
% Make the precision in the ellipse is smaller than that of the collimator.
% So one cell in the collimator will hit only one voxel. 
tic;
xe_pts = linspace(-1*EX, EX, Nx);
ye_pts = linspace(-1*EY, EY, Ny);
ze_pts = linspace(-1*EZ, EZ, Nz);
[Xe, Ye, Ze] = meshgrid(xe_pts, ye_pts, ze_pts);
Xe = Xe(:); Ye = Ye(:); Ze = Ze(:);
P = [Xe, Ye, Ze];
% Plot the mesh
scatter(Xe, Ye, 'g')
fprintf('Creating ellipse mesh: %.02f seconds\n', toc);

%% Determine the necessary flags
% Find the points that fall inside the ellipse
tic;
in_eps_flags = double(subs(E, {x, y}, {P(:,1), P(:,2)})) <= 0;
% Plot the points that fall inside the ellipse
scatter(P(in_eps_flags, 1), P(in_eps_flags, 2), 'm')

% Find the points that are in OAR
o1 = double(subs(O1, {x, y, z}, {P(:,1), P(:,2), P(:, 3)}));
o2 = double(subs(O2, {x, y, z}, {P(:,1), P(:,2), P(:, 3)}));
o3 = double(subs(O3, {x, y, z}, {P(:,1), P(:,2), P(:, 3)}));
in_oar_flags = o1 <= 0 | o2 <= 0 | o3 <= 0;
clear o1 o2 o3
% Plot the points that fall inside the OAR
scatter(P(in_oar_flags, 1), P(in_oar_flags, 2), 'k')

% Find the points inside the tumor
t1 = double(subs(T, {x, y, z}, {P(:,1), P(:,2), P(:, 3)}));
in_tumor_flags = t1 <= 0;
clear t1
% Plot the points that fall inside the OAR
scatter(P(in_tumor_flags, 1), P(in_tumor_flags, 2), 'r')

% Find the points inside the normal tissue
in_normal_flags = (in_eps_flags & ~in_tumor_flags) & ~in_oar_flags;
temp = P(:, 3) == 0; % Find the points on z = 0 only. And make a 2D plot. 
Q = P(temp, :);
scatter(Q(in_normal_flags(temp), 1), Q(in_normal_flags(temp), 2), 'b')
clear temp Q
fprintf('Computing necessary flags: %.02f seconds\n', toc);

%% Discretize the collimator.
tic;
% It is in the Y-Z plane
zc_pts = linspace(-1*CY, CY, CN+1); 
yc_pts = linspace(-1*CY, CY, CN+1); 
% [Zc, Yc] = meshgrid(zc_pts, yc_pts);
% Zc = Zc(:); Yc = Yc(:);
% % HARD CODED: This assumes that the collimator position is perp. to x-axis.
% Xc = EX * ones(size(Yc));
% % Plot the mesh
% % figure; scatter(Zc, Yc, 'b')
% Pc = [Xc, Yc, Zc];

% HARD CODED: This assumes that the collimator position is perp. to x-axis.
% Collimator plane equation: ax + by + cz + d = 0: x = 10
col_plane = [1, 0, 0, -1 * EX]; 
% nx = 1; ny = 0; nz = 0;
fprintf('Discretize collimator: %.02f seconds\n', toc);

%% Loop over and find the matrix
% From the point of view of the collimator. Ambiguous. 
% for idx = 1 : size(Pc, 1)
%    v1 = Pc(idx, :);
%    v2 = v1 + [nx, ny, nz];   
%    dists = point_to_line_distance(P, v1, v2);
%    dists(~in_eps_flags) = inf;
%    flags = dists < d_thresh;
%    scatter(P(flags, 1), P(flags, 2), 'y')
%    pause(3)
% end

tic;
% TODO: Need to tune this parameter. 
d_thresh = min([dxe, dye, dze]);
% Project all voxels in the body on to the collimator. 
[Q, ~] = point_to_plane(col_plane, P); 
% Find if the projected points fall inside the collimator.
[in_col_flags, indices] = where_in_collimator(Q, yc_pts, zc_pts);

% Plot the voxel points on the collimator. 
% figure;
% scatter(Q(in_col_flags, 3), Q(in_col_flags, 2))

% Mark the voxels that are already visited. 
visited_flags = false * ones(size(P, 1), 1);
visited_flags(~in_eps_flags) = true; % Ignore the voxels that are outside the ellipse. 

% Find out the intensity at each voxel. 
intensity_list = zeros(size(P, 1), 1);
% Intensity of voxels outside the ellipse is marked -1. 
intensity_list(~in_eps_flags) = -1; 

% Loop over all points
for idx = 1 : size(P, 1)
   if(visited_flags(idx)); continue; end; % Points that are already visited are ignored. 
   if(~in_col_flags(idx)) % If projected point doesnt fall on collimator, intensity is zero. 
       visited_flags(idx) = true;
       intensity_list(idx) = 0; % This variable is already defaulted to zero.
       continue; 
   end
   
   v1 = P(idx, :); % Point at consideration
   v2 = Q(idx, :); % Projected point on the collimator
   if(isequal(v1, v2))
       % Intensity is exactly equal to initial intensity. 
       visited_flags(idx) = true;
       intensity_list(idx) = F;
       continue
   end
   
   % Find the voxels that are close to the 3D line joined by v1 and v2.
   dists = point_to_line_distance(P, v1, v2);
   dists(~in_eps_flags) = inf;
   flags = dists <= d_thresh;
   % HARD CODED: Need to change it to y-axis when the collimator is perpendicular to y.
   flags = flags & P(:, 1) >= P(idx,1); % Remove the voxels that are to the left of v1.
   
   % HARD CODED: Sort the points w.r.t x-axis. 
   [new_P, I] = sortrows(P(flags, :), 1);
   % Unsort to sort, Use I directly. Sort to unsort, use J instead. 
   temp = sortrows([I, (1:numel(I))'], 1);
   J = temp(:, 2);
   
   % Sanity check. v1 should be the first point in the new set of points. 
   assert(isequal(new_P(1, :), v1), 'Error: Initial point mismatch')
   
   % Find new set of tumor flags. 
   new_tumor_flags = in_tumor_flags(flags);
   new_tumor_flags = new_tumor_flags(I);
   
   % Find new set of normal flags. 
   new_normal_flags = in_normal_flags(flags);
   new_normal_flags = new_normal_flags(I);
   
   % Find new set of OAR flags. 
   new_oar_flags = in_oar_flags(flags);
   new_oar_flags = new_oar_flags(I);
   
   % Combine these three flags. 1 -> normal, 2 -> tumor and 3 -> OAR.
   combined_info = zeros(size(new_tumor_flags));
   combined_info(new_normal_flags == 1) = 1;
   combined_info(new_tumor_flags == 1) = 2;
   combined_info(new_oar_flags == 1) = 3;
   
   % Run a loop backward and upadte the intensities of the respective
   % voxels. 
   temp_intensity_list = zeros(size(combined_info, 1), 1);
   for vid = size(combined_info, 1):-1:1
       COUNT = COUNT + 1;
       if(vid == size(combined_info, 1))
           temp_intensity_list(vid) = F;
           continue;
       end
       if(combined_info(vid) == 1); alph = ALPH_N; end
       if(combined_info(vid) == 2); alph = ALPH_T; end
       if(combined_info(vid) == 3); alph = ALPH_O; end
       temp_intensity_list(vid) = temp_intensity_list(vid + 1) * exp(-1 * alph * UNIT_DISTANCE);
   end
   
   % Unsort the temp_intensity_list w.r.t to orignal array P. Use J. 
   intensity_list(flags) = temp_intensity_list(J); % Sorted to unsorted.
   
   visited_flags(flags) = true;
end
fprintf('Percentage visited: %.02f %% \n', 100*COUNT/size(P, 1))
fprintf('Rest: %.02f seconds\n', toc);
x_indices = indices;
x_intensities = intensity_list;
save('data.mat', 'x_indices', 'x_intensities');

function [in_flags, indices] = where_in_collimator(V, yr, zr)
    %%%%%%%%%%%%%%%%%%%%
    % Description:
    %   Determine the voxels in V, that are effected by the collimator. 
    %   This function checks if the voxels fall with in the range of
    %   collimator y and z axes. 
    % Input:
    %   V - matrix of size N x 3. Each row is an [x, y, z] vector. 
    %   yr - grid of points on collimator along y-direction. It MUST be a
    %   sorted array. 
    %   zr - grid of points on collimator along z-direction. It MUST be a
    %   sorted array. 
    %%%%%%%%%%%%%%%%%%%%
    assert(issorted(yr), 'Error! yr should be a sorted array. ')
    assert(issorted(zr), 'Error! zr should be a sorted array. ')
    assert(size(V, 2) == 3, 'Error! V should have three columns. ')
    
    in_flags = in_collimator(V, yr, zr);
    
    % Initialize
    y = V(:, 2); z = V(:, 3); % Column vectors
    num_y = numel(yr); num_z = numel(zr); % Scalars
    
    % Find the y indices of all points. 
    mat_yr = repmat(yr, numel(y), 1); % Repmat yr to a matrix
    [~, Ky] = sort([mat_yr, y], 2); % Find where y fits into yr
    [row, col] = find(Ky == num_y + 1); % The index of num_y+1 is the desired index of y. 
    temp = sortrows([row, col], 1);
    final_y_ids = temp(:, 2);
    % Substract 1 when values in y are exactly equal to values in yr. 
    final_y_ids = final_y_ids - sum(y == yr, 2); 
    
    % Find the z indices of all points. 
    mat_zr = repmat(zr, numel(z), 1); % Repmat zr to a matrix
    [~, Kz] = sort([mat_zr, z], 2); % Find where z fits into zr
    [row, col] = find(Kz == num_z + 1); % The index of num_z+1 is the desired index of z. 
    % find function randomly shuffles the row ids, so they should be
    %   sorted first. 
    temp = sortrows([row, col], 1);
    final_z_ids = temp(:, 2);
    % Substract 1 when values in z are exactly equal to values in zr. 
    final_z_ids = final_z_ids - sum(z == zr, 2); % sum(z == zr, 2) is vector of ones/zeros.
    
    % Convert (i, j) into an scalar index computed in a column first format. 
    indices = num_y * (final_z_ids - 1) + final_y_ids;
    
    % Finally, set the indices of the points outside the collimator region
    % to zero. Such points might have valid indices due to the way the
    % indices are computed. 
    indices(~in_flags) = 0;
    
    % Sanity check on the indices. 
    assert(min(indices) == 0 && max(indices) == numel(yr)*numel(zr), 'Error! Invalid indices.')
end

function flag = in_collimator(V, yr, zr)
    %%%%%%%%%%%%%%%%%%%%
    % Description:
    %   Determine the voxels in V, that are effected by the collimator. 
    %   This function checks if the voxels fall with in the range of
    %   collimator y and z axes. 
    % Input:
    %   V - matrix of size N x 3. Each row is an [x, y, z] vector. 
    %   yr - grid of points on collimator along y-direction. 
    %   zr - grid of points on collimator along z-direction.
    %%%%%%%%%%%%%%%%%%%%
    y = V(:, 2); z = V(:, 3);
    min_yr = min(yr); max_yr = max(yr);
    min_zr = min(zr); max_zr = max(zr);
    % Initialize
    flag = true * ones(size(y));
    % Check if y falls between y min and y max of collimator
    flag = flag & (y <= max_yr) & (y >= min_yr);
    % Check if z falls between z min and z max of collimator
    flag = flag & (z <= max_zr) & (z >= min_zr);
end